package com.grokonez.jwtauthentication.model;

public enum Role1Name {
    ROLE_LP,
    ROLE_LR,
    ROLE_IG,
    ROLE_IR
}