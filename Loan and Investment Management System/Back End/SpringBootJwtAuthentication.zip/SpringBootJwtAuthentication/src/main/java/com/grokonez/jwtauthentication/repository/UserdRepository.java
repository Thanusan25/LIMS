package com.grokonez.jwtauthentication.repository;

import com.grokonez.jwtauthentication.model.Userd;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserdRepository extends JpaRepository<Userd, Long> {
    Optional<Userd> findByUid(Integer uid);

    Optional<Userd> findByUname(String uname);
}