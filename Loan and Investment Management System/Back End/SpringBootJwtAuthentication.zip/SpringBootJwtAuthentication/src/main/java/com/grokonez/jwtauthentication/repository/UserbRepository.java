package com.grokonez.jwtauthentication.repository;

import com.grokonez.jwtauthentication.model.Userb;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserbRepository extends JpaRepository<Userb, Long> {
    Optional<Userb> findByUid(Integer uid);

    Optional<Userb> findByUname(String uname);

}