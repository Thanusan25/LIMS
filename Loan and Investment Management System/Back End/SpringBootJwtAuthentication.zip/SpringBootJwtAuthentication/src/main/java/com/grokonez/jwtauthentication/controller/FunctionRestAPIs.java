package com.grokonez.jwtauthentication.controller;

import com.grokonez.jwtauthentication.message.request.*;
import com.grokonez.jwtauthentication.message.response.ResponseMessage;
import com.grokonez.jwtauthentication.model.*;
import com.grokonez.jwtauthentication.repository.*;
import com.grokonez.jwtauthentication.security.jwt.JwtProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
//@PreAuthorize("hasAnyAuthority('ROLE_ADMIN')")
@RequestMapping("/api/auth")
public class FunctionRestAPIs {

    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    UserRepository userRepository;

    @Autowired
    UseraRepository useraRepository;

    @Autowired
    UserbRepository userbRepository;

    @Autowired
    UsercRepository usercRepository;

    @Autowired
    UserdRepository userdRepository;


    @Autowired
    UsermessRepository usermessRepository;


    @Autowired
    LawyerRepository lawyerRepository;

    @Autowired
    UserareqRepository userareqRepository;
    @Autowired
    UserbreqRepository userbreqRepository;
    @Autowired
    UsercreqRepository usercreqRepository;
    @Autowired
    UserdreqRepository userdreqRepository;



    @Autowired
    AnnounceRepository announceRepository;



    @Autowired
    UserareqstatusRepository userareqstatusRepository;
    @Autowired
    UserbreqstatusRepository userbreqstatusRepository;
    @Autowired
    UsercreqstatusRepository usercreqstatusRepository;
    @Autowired
    UserdreqstatusRepository userdreqstatusRepository;


    @Autowired
    RoleRepository roleRepository;
    @Autowired
    Role1Repository role1Repository;

    @Autowired
    PasswordEncoder encoder;

    @Autowired
    JwtProvider jwtProvider;


//-----------------------------------------------------------------------
// to get user details

    @GetMapping("/user")
    public List<User> getAllUsers() {

        System.out.println("Get all Users...");

        List<User> users = new ArrayList<>();
        userRepository.findAll().forEach(users::add);
        return users;

    }

// delect users


    @DeleteMapping("/user/delete")
    public ResponseEntity<String> deleteAllUsers() {
        System.out.println("Delete All users...");

        userRepository.deleteAll();

        return new ResponseEntity<>("All Users have been deleted!", HttpStatus.OK);
    }


    @DeleteMapping("/user/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable("id") long id) {
        System.out.println("Delete users with ID = " + id + "...");

        userRepository.deleteById(id);

        return new ResponseEntity<>("User has been deleted!", HttpStatus.OK);
    }


    @GetMapping(value = "user/username/{username}")
    public Optional<User> findByUsername(@PathVariable String username) {

        Optional<User> users = userRepository.findByUsername(username);
        return users;
    }



//---------------------------------------------------------------------------------------------


//---------------------------------------------------------------------------------------------


//---------------------------------------------------------------------------------------------


// user messages


    //------------------------------------------------------------------------------------
// usera Request

    @PostMapping("/userareq")
    public ResponseEntity<?> registerUserareq(@Valid @RequestBody PreqForm signUpRequest) {

        // Creating user's account
        UseraReq userareq = new UseraReq(signUpRequest.getUname(),signUpRequest.getAmount(),signUpRequest.getDuration(),signUpRequest.getRate(),signUpRequest.getNegotiation(),signUpRequest.getDate());


        userareqRepository.save(userareq);

        return new ResponseEntity<>(new ResponseMessage("Usermess registered successfully!"), HttpStatus.OK);
    }

    @GetMapping("/getuserareq")
    public List<UseraReq> getAllUseraReqs() {

        System.out.println("Get all UseraReq...");

        List<UseraReq> userareqs = new ArrayList<>();
        userareqRepository.findAll().forEach(userareqs::add);

        return userareqs;

    }

    @GetMapping(value = "getuserareq/uname/{uname}")
    public List<UseraReq> findByunamear(@PathVariable String uname) {

        List<UseraReq> userareq = userareqRepository.findByUname(uname);
        return userareq;
    }

    @DeleteMapping("/userareq/delete/{id}")
    public ResponseEntity<String> deleteUserareq(@PathVariable("id") long id) {
        System.out.println("Delete userareq with ID = " + id + "...");

        userareqRepository.deleteById(id);

        return new ResponseEntity<>("Usera request has been deleted!", HttpStatus.OK);
    }

//------------------------------------------------------------------------------------
// userb Request

    @PostMapping("/userbreq")
    public ResponseEntity<?> registerUserbreq(@Valid @RequestBody SreqForm signUpRequest) {

        // Creating user's account
        UserbReq userbreq = new UserbReq(signUpRequest.getUname(),signUpRequest.getAmount(),signUpRequest.getDuration(),signUpRequest.getRate(),signUpRequest.getNegotiation(),signUpRequest.getDate());


        userbreqRepository.save(userbreq);

        return new ResponseEntity<>(new ResponseMessage("Usermess registered successfully!"), HttpStatus.OK);
    }

    @GetMapping("/getuserbreq")
    public List<UserbReq> getAllUserbReqs() {

        System.out.println("Get all UserbReq...");

        List<UserbReq> userbreqs = new ArrayList<>();
        userbreqRepository.findAll().forEach(userbreqs::add);

        return userbreqs;

    }



    @GetMapping(value = "getuserbreq/uname/{uname}")
    public List<UserbReq> findByunamebr(@PathVariable String uname) {

        List<UserbReq> userbreq = userbreqRepository.findByUname(uname);
        return userbreq;
    }

    @DeleteMapping("/userbreq/delete/{id}")
    public ResponseEntity<String> deleteUserbreq(@PathVariable("id") long id) {
        System.out.println("Delete userbreq with ID = " + id + "...");

        userbreqRepository.deleteById(id);

        return new ResponseEntity<>("Userb request has been deleted!", HttpStatus.OK);
    }

//--------------------------------------------------------------------------------------------------------
// userc Request

    @PostMapping("/usercreq")
    public ResponseEntity<?> registerUsercreq(@Valid @RequestBody IgreqForm signUpRequest) {

        // Creating user's account
        UsercReq usercreq = new UsercReq(signUpRequest.getUname(),signUpRequest.getAmount(),signUpRequest.getDuration(),signUpRequest.getRate(),signUpRequest.getNegotiation(),signUpRequest.getDate());


        usercreqRepository.save(usercreq);

        return new ResponseEntity<>(new ResponseMessage("Usermess registered successfully!"), HttpStatus.OK);
    }



    @GetMapping("/getusercreq")
    public List<UsercReq> getAllUsercReqs() {

        System.out.println("Get all UsercReq...");

        List<UsercReq> usercreqs = new ArrayList<>();
        usercreqRepository.findAll().forEach(usercreqs::add);

        return usercreqs;

    }

    @GetMapping(value = "getusercreq/uname/{uname}")
    public List<UsercReq> findByunamecr(@PathVariable String uname) {

        List<UsercReq> usercreq = usercreqRepository.findByUname(uname);
        return usercreq;
    }



    @DeleteMapping("/usercreq/delete/{id}")
    public ResponseEntity<String> deleteUsercreq(@PathVariable("id") long id) {
        System.out.println("Delete usercreq with ID = " + id + "...");

        usercreqRepository.deleteById(id);

        return new ResponseEntity<>("Userc request has been deleted!", HttpStatus.OK);
    }

//-------------------------------------------------------------------------------------------------------
// userd Request

    @PostMapping("/userdreq")
    public ResponseEntity<?> registerUserdreq(@Valid @RequestBody IrreqForm signUpRequest) {

        // Creating user's account
        UserdReq userdreq = new UserdReq(signUpRequest.getUname(),signUpRequest.getArea(),signUpRequest.getAmount(),signUpRequest.getDuration(),signUpRequest.getRate(),signUpRequest.getNegotiation(),signUpRequest.getDate());


        userdreqRepository.save(userdreq);

        return new ResponseEntity<>(new ResponseMessage("Usermess registered successfully!"), HttpStatus.OK);
    }



    @GetMapping("/getuserdreq")
    public List<UserdReq> getAllUserdReqs() {

        System.out.println("Get all UserdReq...");

        List<UserdReq> userdreqs = new ArrayList<>();
        userdreqRepository.findAll().forEach(userdreqs::add);

        return userdreqs;

    }



    @GetMapping(value = "getuserdreq/uname/{uname}")
    public List<UserdReq> findByunamedr(@PathVariable String uname) {

        List<UserdReq> userdreq = userdreqRepository.findByUname(uname);
        return userdreq;
    }

    @DeleteMapping("/userdreq/delete/{id}")
    public ResponseEntity<String> deleteUserdreq(@PathVariable("id") long id) {
        System.out.println("Delete userdreq with ID = " + id + "...");

        userdreqRepository.deleteById(id);

        return new ResponseEntity<>("Userd request has been deleted!", HttpStatus.OK);
    }


//----------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------
    //lawyer


    @PostMapping("/lawyer")
    public ResponseEntity<?> registerLawyer(@Valid @RequestBody LawyerForm signUpRequest) {

        // Creating user's account
        Lawyer lawyer = new Lawyer(signUpRequest.getUid(),signUpRequest.getUname(),signUpRequest.getName(), signUpRequest.getUsername(), signUpRequest.getEmail(),
                encoder.encode(signUpRequest.getPassword()));

        lawyerRepository.save(lawyer);

        return new ResponseEntity<>(new ResponseMessage("LawyerregForm registered successfully!"), HttpStatus.OK);
    }



    @GetMapping("/getlawyer")
    public List<Lawyer> getAllLawyers() {

        System.out.println("Get all Lawyer...");

        List<Lawyer> lawyer = new ArrayList<>();
        lawyerRepository.findAll().forEach(lawyer::add);

        return lawyer;

    }
//----------------------------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------------
    //Announcement


    @PostMapping("/announce")
    public ResponseEntity<?> registerAnnounce(@Valid @RequestBody AnnounceForm signUpRequest) {

        // Creating user's account
        Announcement announcement = new Announcement(signUpRequest.getAname(),signUpRequest.getMessage(),signUpRequest.getDate());

        announceRepository.save(	announcement);

        return new ResponseEntity<>(new ResponseMessage("Announcement send successfully!"), HttpStatus.OK);
    }



    @GetMapping("/getannounce")
    public List<Announcement> getAllAnnouncement() {

        System.out.println("Get all Announcement...");

        List<Announcement> 	announcement = new ArrayList<>();
        announceRepository.findAll().forEach(	announcement::add);

        return 	announcement;

    }
//---------------------------------------------------------------------------------------------------------
//--------usera status of the request



    // usera request status sending
    @PostMapping("/userareqstatus")
    public ResponseEntity<?> registerUsercreq(@Valid @RequestBody PreqStatus signUpRequest) {

        // Creating user's account
        UseraReqStatus pstatus = new UseraReqStatus(signUpRequest.getReqid(),signUpRequest.getRuname(),signUpRequest.getSuname(),signUpRequest.getReceiverstatus(),signUpRequest.getSenderstatus(),signUpRequest.getLawyer(),signUpRequest.getComments());


        userareqstatusRepository.save(pstatus);

        return new ResponseEntity<>(new ResponseMessage("Usera status  successfully updated"), HttpStatus.OK);
    }

// usera request status updating


    @PutMapping("/userareqstatus/{id}")
    public ResponseEntity<UseraReqStatus> updateCustomer(@PathVariable("id") long id, @RequestBody PreqStatus pstatus) {
        System.out.println("Update Customer with ID = " + id + "...");

        Optional<UseraReqStatus> customerData = userareqstatusRepository.findById(id);

        if (customerData.isPresent()) {
            UseraReqStatus _pstatus  = customerData.get();
            _pstatus.setReqid(pstatus.getReqid());
            _pstatus.setRuname(pstatus.getRuname());
            _pstatus.setSuname(pstatus.getSuname());
            _pstatus.setReceiverstatus(pstatus.getReceiverstatus());
            _pstatus.setSenderstatus(pstatus.getSenderstatus());
            _pstatus.setLawyer(pstatus.getLawyer());
            _pstatus.setComments(pstatus.getComments());




            return new ResponseEntity<>(userareqstatusRepository.save(_pstatus), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }



    @GetMapping(value = "getuserareqstatus/runame/{runame}/status/{receiverstatus}")
    public List<UseraReqStatus> findByunameStatus(@PathVariable String runame,@PathVariable String receiverstatus) {

        List<UseraReqStatus> userareqstatus = userareqstatusRepository.findByRunameAndReceiverstatus(runame,receiverstatus);
        return userareqstatus;
    }


    @GetMapping(value = "getuserareqstatusr/reqid/{reqid}/runame/{runame}/status/{receiverstatus}")
    public Optional<UseraReqStatus> findByunameStatusReqid(@PathVariable Integer reqid,@PathVariable String runame,@PathVariable String receiverstatus) {

        Optional<UseraReqStatus> userareqstatus = userareqstatusRepository.findByRunameAndReceiverstatusAndReqid(runame,receiverstatus,reqid);
        return userareqstatus;
    }


////////////////////////////////////////////////////////////////////////////

    //--------userb status of the request



    // userb request status sending
    @PostMapping("/userbreqstatus")
    public ResponseEntity<?> registerUserbreq(@Valid @RequestBody SreqStatus signUpRequest) {

        // Creating user's account
        UserbReqStatus sstatus = new UserbReqStatus(signUpRequest.getReqid(),signUpRequest.getRuname(),signUpRequest.getSuname(),signUpRequest.getReceiverstatus(),signUpRequest.getSenderstatus(),signUpRequest.getLawyer(),signUpRequest.getComments());


        userbreqstatusRepository.save(sstatus);

        return new ResponseEntity<>(new ResponseMessage("Usera status  successfully updated"), HttpStatus.OK);
    }

// usera request status updating


    @PutMapping("/userbreqstatus/{id}")
    public ResponseEntity<UserbReqStatus> updateUserbreqStatus(@PathVariable("id") long id, @RequestBody PreqStatus sstatus) {
        System.out.println("Update Customer with ID = " + id + "...");

        Optional<UserbReqStatus> userbreqStatusData = userbreqstatusRepository.findById(id);

        if (userbreqStatusData.isPresent()) {
            UserbReqStatus _sstatus  = userbreqStatusData.get();
            _sstatus.setReqid(sstatus.getReqid());
            _sstatus.setRuname(sstatus.getRuname());
            _sstatus.setSuname(sstatus.getSuname());
            _sstatus.setReceiverstatus(sstatus.getReceiverstatus());
            _sstatus.setSenderstatus(sstatus.getSenderstatus());
            _sstatus.setLawyer(sstatus.getLawyer());
            _sstatus.setComments(sstatus.getComments());




            return new ResponseEntity<>(userbreqstatusRepository.save(_sstatus), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }



    @GetMapping(value = "getuserbreqstatus/runame/{runame}/status/{receiverstatus}")
    public List<UserbReqStatus> findbByunameStatus(@PathVariable String runame,@PathVariable String receiverstatus) {

        List<UserbReqStatus> userbreqstatus = userbreqstatusRepository.findByRunameAndReceiverstatus(runame,receiverstatus);
        return userbreqstatus;
    }


    @GetMapping(value = "getuserbreqstatus/runame/{runame}")
    public List<UserbReqStatus> findbByRuname(@PathVariable String runame) {

        List<UserbReqStatus> userbreqstatus = userbreqstatusRepository.findByRuname(runame);
        return userbreqstatus;
    }



    @GetMapping(value = "getuserbreqstatusr/reqid/{reqid}/runame/{runame}/status/{receiverstatus}")
    public Optional<UserbReqStatus> findbByunameStatusReqid(@PathVariable Integer reqid,@PathVariable String runame,@PathVariable String receiverstatus) {

        Optional<UserbReqStatus> userbreqstatus = userbreqstatusRepository.findByRunameAndReceiverstatusAndReqid(runame,receiverstatus,reqid);
        return userbreqstatus;
    }



////////////////////////////////////////////////////////////////////////////
//--------userc status of the request



    // userc request status sending
    @PostMapping("/usercreqstatus")
    public ResponseEntity<?> registerUsercreq(@Valid @RequestBody SreqStatus signUpRequest) {

        // Creating user's account
        UsercReqStatus sstatus = new UsercReqStatus(signUpRequest.getReqid(),signUpRequest.getRuname(),signUpRequest.getSuname(),signUpRequest.getReceiverstatus(),signUpRequest.getSenderstatus(),signUpRequest.getLawyer(),signUpRequest.getComments());


        usercreqstatusRepository.save(sstatus);

        return new ResponseEntity<>(new ResponseMessage("Usera status  successfully updated"), HttpStatus.OK);
    }

// usera request status updating


    @PutMapping("/usercreqstatus/{id}")
    public ResponseEntity<UsercReqStatus> updateUsercreqStatus(@PathVariable("id") long id, @RequestBody PreqStatus sstatus) {
        System.out.println("Update Customer with ID = " + id + "...");

        Optional<UsercReqStatus> usercreqStatusData = usercreqstatusRepository.findById(id);

        if (usercreqStatusData.isPresent()) {
            UsercReqStatus _sstatus  = usercreqStatusData.get();
            _sstatus.setReqid(sstatus.getReqid());
            _sstatus.setRuname(sstatus.getRuname());
            _sstatus.setSuname(sstatus.getSuname());
            _sstatus.setReceiverstatus(sstatus.getReceiverstatus());
            _sstatus.setSenderstatus(sstatus.getSenderstatus());
            _sstatus.setLawyer(sstatus.getLawyer());
            _sstatus.setComments(sstatus.getComments());




            return new ResponseEntity<>(usercreqstatusRepository.save(_sstatus), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }



    @GetMapping(value = "getusercreqstatus/runame/{runame}/status/{receiverstatus}")
    public List<UsercReqStatus> findbByunameStatususerc(@PathVariable String runame,@PathVariable String receiverstatus) {

        List<UsercReqStatus> usercreqstatus = usercreqstatusRepository.findByRunameAndReceiverstatus(runame,receiverstatus);
        return usercreqstatus;
    }


    @GetMapping(value = "getusercreqstatus/runame/{runame}")
    public List<UsercReqStatus> findbByRunameuserc(@PathVariable String runame) {

        List<UsercReqStatus> usercreqstatus = usercreqstatusRepository.findByRuname(runame);
        return usercreqstatus;
    }



    @GetMapping(value = "getusercreqstatusr/reqid/{reqid}/runame/{runame}/status/{receiverstatus}")
    public Optional<UsercReqStatus> findbByunameStatusReqiduserc(@PathVariable Integer reqid,@PathVariable String runame,@PathVariable String receiverstatus) {

        Optional<UsercReqStatus> usercreqstatus = usercreqstatusRepository.findByRunameAndReceiverstatusAndReqid(runame,receiverstatus,reqid);
        return usercreqstatus;
    }



    ////////////////////////////////////////////////////////////////////////////

    //--------userd status of the request



    // userd request status sending
    @PostMapping("/userdreqstatus")
    public ResponseEntity<?> registerUserdreq(@Valid @RequestBody SreqStatus signUpRequest) {

        // Creating user's account
        UserdReqStatus sstatus = new UserdReqStatus(signUpRequest.getReqid(),signUpRequest.getRuname(),signUpRequest.getSuname(),signUpRequest.getReceiverstatus(),signUpRequest.getSenderstatus(),signUpRequest.getLawyer(),signUpRequest.getComments());


        userdreqstatusRepository.save(sstatus);

        return new ResponseEntity<>(new ResponseMessage("Usera status  successfully updated"), HttpStatus.OK);
    }

// usera request status updating


    @PutMapping("/userdreqstatus/{id}")
    public ResponseEntity<UserdReqStatus> updateUserdreqStatus(@PathVariable("id") long id, @RequestBody PreqStatus sstatus) {
        System.out.println("Update Customer with ID = " + id + "...");

        Optional<UserdReqStatus> userdreqStatusData = userdreqstatusRepository.findById(id);

        if (userdreqStatusData.isPresent()) {
            UserdReqStatus _sstatus  = userdreqStatusData.get();
            _sstatus.setReqid(sstatus.getReqid());
            _sstatus.setRuname(sstatus.getRuname());
            _sstatus.setSuname(sstatus.getSuname());
            _sstatus.setReceiverstatus(sstatus.getReceiverstatus());
            _sstatus.setSenderstatus(sstatus.getSenderstatus());
            _sstatus.setLawyer(sstatus.getLawyer());
            _sstatus.setComments(sstatus.getComments());




            return new ResponseEntity<>(userdreqstatusRepository.save(_sstatus), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }



    @GetMapping(value = "getuserdreqstatus/runame/{runame}/status/{receiverstatus}")
    public List<UserdReqStatus> findbByunameStatususerd(@PathVariable String runame,@PathVariable String receiverstatus) {

        List<UserdReqStatus> userdreqstatus = userdreqstatusRepository.findByRunameAndReceiverstatus(runame,receiverstatus);
        return userdreqstatus;
    }



    @GetMapping(value = "getuserdreqstatus/runame/{runame}")
    public List<UserdReqStatus> findbByRunameuserd(@PathVariable String runame) {

        List<UserdReqStatus> userdreqstatus = userdreqstatusRepository.findByRuname(runame);
        return userdreqstatus;
    }




    @GetMapping(value = "getuserdreqstatusr/reqid/{reqid}/runame/{runame}/status/{receiverstatus}")
    public Optional<UserdReqStatus> findbByunameStatusReqiduserd(@PathVariable Integer reqid,@PathVariable String runame,@PathVariable String receiverstatus) {

        Optional<UserdReqStatus> userdreqstatus = userdreqstatusRepository.findByRunameAndReceiverstatusAndReqid(runame,receiverstatus,reqid);
        return userdreqstatus;
    }


}
