package com.grokonez.jwtauthentication.repository;

import com.grokonez.jwtauthentication.model.Userc;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UsercRepository extends JpaRepository<Userc, Long> {

    Optional<Userc> findByUid(Integer uid);
    Optional<Userc> findByUname(String uname);


}