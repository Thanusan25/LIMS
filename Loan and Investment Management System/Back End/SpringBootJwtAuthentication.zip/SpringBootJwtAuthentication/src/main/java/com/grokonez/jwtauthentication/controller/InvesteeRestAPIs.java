package com.grokonez.jwtauthentication.controller;

import com.grokonez.jwtauthentication.message.request.*;
import com.grokonez.jwtauthentication.message.response.ResponseMessage;
import com.grokonez.jwtauthentication.model.*;
import com.grokonez.jwtauthentication.repository.*;
import com.grokonez.jwtauthentication.security.jwt.JwtProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
//@PreAuthorize("hasAnyAuthority('ROLE_ADMIN')")
@RequestMapping("/api/auth")

public class InvesteeRestAPIs {


    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    UserRepository userRepository;

    @Autowired
    UseraRepository useraRepository;

    @Autowired
    UserbRepository userbRepository;

    @Autowired
    UsercRepository usercRepository;

    @Autowired
    UserdRepository userdRepository;


    @Autowired
    UsermessRepository usermessRepository;


    @Autowired
    LawyerRepository lawyerRepository;

    @Autowired
    UserareqRepository userareqRepository;
    @Autowired
    UserbreqRepository userbreqRepository;
    @Autowired
    UsercreqRepository usercreqRepository;
    @Autowired
    UserdreqRepository userdreqRepository;



    @Autowired
    AnnounceRepository announceRepository;



    @Autowired
    UserareqstatusRepository userareqstatusRepository;
    @Autowired
    UserbreqstatusRepository userbreqstatusRepository;
    @Autowired
    UsercreqstatusRepository usercreqstatusRepository;
    @Autowired
    UserdreqstatusRepository userdreqstatusRepository;


    @Autowired
    RoleRepository roleRepository;
    @Autowired
    Role1Repository role1Repository;

    @Autowired
    PasswordEncoder encoder;

    @Autowired
    JwtProvider jwtProvider;


    // userd detatils

    @PostMapping("/irsignup")
    public ResponseEntity<?> registerUserd(@Valid @RequestBody IrsignUpForm signUpRequest) {

        // Creating user's account
        Userd userd = new Userd(signUpRequest.getUid(),signUpRequest.getUname(),signUpRequest.getName(), signUpRequest.getYearsofoccupation(), signUpRequest.getSalary(), signUpRequest.getName(), signUpRequest.getGnic(), signUpRequest.getGphonenumber(), signUpRequest.getGjob(), signUpRequest.getGrelationship());



        userdRepository.save(userd);

        return new ResponseEntity<>(new ResponseMessage("Userd registered successfully!"), HttpStatus.OK);
    }


    @GetMapping("/userd")
    public List<Userd> getAllUserds() {

        System.out.println("Get all Userds...");

        List<Userd> userds = new ArrayList<>();
        userdRepository.findAll().forEach(userds::add);

        return userds;

    }


    @DeleteMapping("/userd/{id}")
    public ResponseEntity<String> deleteUserd(@PathVariable("id") long id) {
        System.out.println("Delete userbs with ID = " + id + "...");

        userdRepository.deleteById(id);

        return new ResponseEntity<>("Userd has been deleted!", HttpStatus.OK);
    }

    @DeleteMapping("/userd/delete")
    public ResponseEntity<String> deleteAllUserds() {
        System.out.println("Delete All userds...");

        userdRepository.deleteAll();

        return new ResponseEntity<>("All Userds have been deleted!", HttpStatus.OK);
    }

    @GetMapping(value = "userd/uid/{uid}")
    public Optional<Userd> findByU_idd(@PathVariable Integer uid) {

        Optional<Userd> userds = userdRepository.findByUid(uid);
        return userds;
    }


    @GetMapping(value = "userd/uname/{uname}")
    public Optional<Userd> findByUnamed(@PathVariable String uname) {

        Optional<Userd> userds = userdRepository.findByUname(uname);
        return userds;
    }
//------------------------------------------------------------------------------------

}

