package com.grokonez.jwtauthentication.repository;

import com.grokonez.jwtauthentication.model.Lawyer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface LawyerRepository extends JpaRepository<Lawyer, Long> {
    Optional<Lawyer> findByUid(Integer uid);
    Optional<Lawyer> findByUsername(String username);
    Optional<Lawyer> findByUname(String uname);

    Boolean existsByUsername(String username);
    Boolean existsByEmail(String email);
}