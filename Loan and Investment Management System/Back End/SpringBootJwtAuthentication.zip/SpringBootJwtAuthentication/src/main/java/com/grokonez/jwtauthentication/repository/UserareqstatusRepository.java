
package com.grokonez.jwtauthentication.repository;

        import com.grokonez.jwtauthentication.model.UseraReqStatus;
        import com.grokonez.jwtauthentication.model.Usermess;
        import org.springframework.data.jpa.repository.JpaRepository;
        import org.springframework.stereotype.Repository;

        import java.util.List;
        import java.util.Optional;

@Repository
public interface UserareqstatusRepository extends JpaRepository<UseraReqStatus, Long> {


    List<UseraReqStatus> findByRuname(String runame);
    List<UseraReqStatus> findByRunameAndReceiverstatus(String runame,String receiverstatus);
    Optional<UseraReqStatus> findByRunameAndReceiverstatusAndReqid(String runame,String receiverstatus,Integer reqid);

    Optional<UseraReqStatus> findById(Long id);



}
