package com.grokonez.jwtauthentication.model;

import org.hibernate.annotations.NaturalId;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.util.HashSet;
import java.util.Set;


@Entity
@Table(name = "UseraReq", uniqueConstraints = {
        @UniqueConstraint(columnNames = {
                "id"
        })
})
public class UseraReq {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Size(min = 3, max = 50)
    private String uname;

    @NotNull
    @Min(value =1)
    private Integer amount;


    @NotNull
    @Min(value =1)
    private Integer duration;

    @NotNull
    @Min(value =1)
    private Integer rate;



    @NotBlank
    @Size(min=3, max = 50)
    private String negotiation;

    @NotBlank
    @Size(min=3, max = 100)
    private String date;



    public UseraReq() {}

    public UseraReq(String uname,Integer amount,Integer duration,Integer rate, String negotiation,String date) {
       this.uname = uname;
        this.amount = amount;
        this.duration = duration;
        this.rate = rate;
        this.negotiation= negotiation;
        this.date=date;


    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }



    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }


    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }


    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }


    public Integer getRate() {
        return rate;
    }

    public void setRate(Integer rate) {
        this.rate = rate;
    }


    public String getNegotiation() {
        return negotiation;
    }

    public void setNegotiation(String negotiation) {
        this.negotiation = negotiation;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

}