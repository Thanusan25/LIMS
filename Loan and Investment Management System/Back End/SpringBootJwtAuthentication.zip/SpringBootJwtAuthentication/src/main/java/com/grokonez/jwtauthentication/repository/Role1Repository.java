package com.grokonez.jwtauthentication.repository;

import com.grokonez.jwtauthentication.model.Role1;
import com.grokonez.jwtauthentication.model.Role1Name;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface Role1Repository extends JpaRepository<Role1, Long> {
    Optional<Role1> findByName(Role1Name role1Name);
}