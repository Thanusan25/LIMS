
package com.grokonez.jwtauthentication.repository;

import com.grokonez.jwtauthentication.model.UserdReqStatus;
import com.grokonez.jwtauthentication.model.Usermess;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserdreqstatusRepository extends JpaRepository<UserdReqStatus, Long> {


    List<UserdReqStatus> findByRuname(String runame);
    List<UserdReqStatus> findByRunameAndReceiverstatus(String runame,String receiverstatus);
    Optional<UserdReqStatus> findByRunameAndReceiverstatusAndReqid(String runame,String receiverstatus,Integer reqid);

    Optional<UserdReqStatus> findById(Long id);



}
