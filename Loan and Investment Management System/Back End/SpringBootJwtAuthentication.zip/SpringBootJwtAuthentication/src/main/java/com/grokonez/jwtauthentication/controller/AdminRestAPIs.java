package com.grokonez.jwtauthentication.controller;

import com.grokonez.jwtauthentication.message.request.*;
import com.grokonez.jwtauthentication.message.response.ResponseMessage;
import com.grokonez.jwtauthentication.model.*;
import com.grokonez.jwtauthentication.repository.*;
import com.grokonez.jwtauthentication.security.jwt.JwtProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
//@PreAuthorize("hasAnyAuthority('ROLE_ADMIN')")
@RequestMapping("/api/auth")
public class AdminRestAPIs {


    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    UserRepository userRepository;

    @Autowired
    UseraRepository useraRepository;

    @Autowired
    UserbRepository userbRepository;

    @Autowired
    UsercRepository usercRepository;

    @Autowired
    UserdRepository userdRepository;


    @Autowired
    UsermessRepository usermessRepository;


    @Autowired
    LawyerRepository lawyerRepository;

    @Autowired
    UserareqRepository userareqRepository;
    @Autowired
    UserbreqRepository userbreqRepository;
    @Autowired
    UsercreqRepository usercreqRepository;
    @Autowired
    UserdreqRepository userdreqRepository;



    @Autowired
    AnnounceRepository announceRepository;



    @Autowired
    UserareqstatusRepository userareqstatusRepository;
    @Autowired
    UserbreqstatusRepository userbreqstatusRepository;
    @Autowired
    UsercreqstatusRepository usercreqstatusRepository;
    @Autowired
    UserdreqstatusRepository userdreqstatusRepository;


    @Autowired
    RoleRepository roleRepository;
    @Autowired
    Role1Repository role1Repository;

    @Autowired
    PasswordEncoder encoder;

    @Autowired
    JwtProvider jwtProvider;




}

