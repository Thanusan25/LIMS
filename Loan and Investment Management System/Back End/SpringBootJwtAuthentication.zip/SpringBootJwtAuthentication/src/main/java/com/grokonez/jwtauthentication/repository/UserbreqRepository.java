package com.grokonez.jwtauthentication.repository;

import com.grokonez.jwtauthentication.model.UseraReq;
import com.grokonez.jwtauthentication.model.UserbReq;
import com.grokonez.jwtauthentication.model.Usermess;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserbreqRepository extends JpaRepository<UserbReq, Long> {


    List<UserbReq> findByUname(String uname);



}
