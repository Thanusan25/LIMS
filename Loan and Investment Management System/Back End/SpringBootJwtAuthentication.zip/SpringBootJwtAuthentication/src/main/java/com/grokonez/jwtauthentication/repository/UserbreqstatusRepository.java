
package com.grokonez.jwtauthentication.repository;

import com.grokonez.jwtauthentication.model.UserbReqStatus;
import com.grokonez.jwtauthentication.model.Usermess;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserbreqstatusRepository extends JpaRepository<UserbReqStatus, Long> {



    List<UserbReqStatus> findByRuname(String runame);
    List<UserbReqStatus> findByRunameAndReceiverstatus(String runame,String receiverstatus);
    Optional<UserbReqStatus> findByRunameAndReceiverstatusAndReqid(String runame,String receiverstatus,Integer reqid);

    Optional<UserbReqStatus> findById(Long id);




}
