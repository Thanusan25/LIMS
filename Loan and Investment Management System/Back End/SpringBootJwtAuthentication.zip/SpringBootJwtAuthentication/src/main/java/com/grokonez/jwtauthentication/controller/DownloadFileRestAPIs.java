package com.grokonez.jwtauthentication.controller;

import com.fasterxml.jackson.annotation.JsonView;
import com.grokonez.jwtauthentication.model.FileModel;
import com.grokonez.jwtauthentication.model.View;
import com.grokonez.jwtauthentication.repository.FileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/auth")
public class DownloadFileRestAPIs {
    @Autowired
    FileRepository fileRepository;

    @JsonView(View.FileInfo.class)
    @GetMapping("/file/all")
    public List<FileModel> getListFiles() {
        return fileRepository.findAll();
    }

    /*
     * Download Files
     */
    @GetMapping("/file/{id}")
    public ResponseEntity<Object> getFile(@PathVariable Long id) {
        Optional<FileModel> fileOptional = fileRepository.findById(id);

        if(fileOptional.isPresent()) {
            FileModel file = fileOptional.get();
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getName() + "\"")
                    .body(file.getPic());
        }

        return ResponseEntity.status(404).body(null);
    }
}
