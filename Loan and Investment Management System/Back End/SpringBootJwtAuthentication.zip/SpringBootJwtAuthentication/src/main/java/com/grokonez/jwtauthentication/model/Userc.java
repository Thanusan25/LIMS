package com.grokonez.jwtauthentication.model;

import org.hibernate.annotations.NaturalId;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "usersc", uniqueConstraints = {
        @UniqueConstraint(columnNames = {
                "uid"
        }),
        @UniqueConstraint(columnNames = {
                "uname"
        })
})
public class Userc {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Min(value =1)
    private Integer uid;


    @NotBlank
    @Size(min = 3, max = 50)
    private String uname;


    @NotBlank
    @Size(min=3, max = 50)
    private String name;

    @NotBlank
    @Size(min=3, max = 50)
    private String areas;

    @NotBlank
    @Size(min=6, max = 100)
    private String minrate;

    @NotBlank
    @Size(min=6, max = 100)
    private String about;



    public Userc() {}

    public Userc(Integer uid,String uname,String name, String areas,  String minrate,String about) {
        this.uid = uid;
        this.uname = uname;
        this.name = name;
        this.areas = areas;
        this.minrate = minrate;
        this.about = about;

    }



    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }


    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }



    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getAreas() {
        return areas;
    }

    public void setAreas(String areas) {
        this.areas = areas;
    }

    public String getMinrate() {
        return minrate;
    }

    public void setMinrate(String minrate) {
        this.minrate = minrate;
    }

    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }
}