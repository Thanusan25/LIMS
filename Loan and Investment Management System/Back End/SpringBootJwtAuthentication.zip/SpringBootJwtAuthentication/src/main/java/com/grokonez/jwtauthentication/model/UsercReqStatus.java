package com.grokonez.jwtauthentication.model;

import org.hibernate.annotations.NaturalId;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "UsercReqStatus", uniqueConstraints = {
        @UniqueConstraint(columnNames = {
                "reqid","runame"
        })
})
public class UsercReqStatus {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Size(min = 3, max = 50)
    private String runame;

    @NotBlank
    @Size(min = 3, max = 50)
    private String suname;



    @NotNull
    @Min(value =1)
    private Integer reqid;


    @NotBlank
    @Size(min = 3, max = 50)
    private String receiverstatus;


    @NotBlank
    @Size(min = 3, max = 50)
    private String senderstatus;

    @NotBlank
    @Size(min = 3, max = 50)
    private String lawyer;


    @NotBlank
    @Size(min=3, max = 50)
    private String comments;




    public UsercReqStatus() {}

    public UsercReqStatus(Integer reqid,String runame,String suname,String receiverstatus ,String senderstatus,String lawyer,String comments)
    {
        this.reqid = reqid;
        this.runame = runame;
        this.suname = suname;
        this.receiverstatus = receiverstatus;
        this.senderstatus= senderstatus;

        this.lawyer= lawyer;
        this.comments= comments;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public String getRuname() {
        return runame;
    }

    public void setRuname(String runame) {
        this.runame = runame;
    }

    public String getSuname() {
        return suname;
    }

    public void setSuname(String suname) {
        this.suname = suname;
    }

    public Integer getReqid() {
        return reqid;
    }

    public void setReqid(Integer reqid) {
        this.reqid = reqid;
    }

    public String getReceiverstatus() {
        return receiverstatus;
    }

    public void setReceiverstatus(String receiverstatus) {
        this.receiverstatus = receiverstatus;
    }

    public String getSenderstatus() {
        return senderstatus;
    }

    public void setSenderstatus(String senderstatus) {
        this.senderstatus = senderstatus;
    }

    public String getLawyer() {
        return lawyer;
    }

    public void setLawyer(String lawyer) {
        this.lawyer = lawyer;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }


}