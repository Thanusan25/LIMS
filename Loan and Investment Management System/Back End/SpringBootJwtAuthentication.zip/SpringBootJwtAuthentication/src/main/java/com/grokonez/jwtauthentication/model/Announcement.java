package com.grokonez.jwtauthentication.model;

 import org.hibernate.annotations.NaturalId;

 import javax.persistence.*;
 import javax.validation.constraints.*;
 import java.util.HashSet;
 import java.util.Set;

 @Entity
 @Table(name = "announcements", uniqueConstraints = {
         @UniqueConstraint(columnNames = {
                 "id"
         })
 })
 public class  Announcement {
     @Id
     @GeneratedValue(strategy = GenerationType.IDENTITY)
     private Long id;


     @NotBlank
     @Size(min = 3, max = 50)
     private String aname;


     @NotBlank
     @Size(min=3, max = 50)
     private String message;

     @NotBlank
     @Size(min=3, max = 100)
     private String date;




     public  Announcement () {}

     public Announcement (String aname,String message,String date) {
         this.aname = aname;
         this.message = message;

         this.date=date;


     }


     public String getAname() {
         return aname;
     }

     public void setAname(String aname) {
         this.aname = aname;
     }


     public Long getId() {
         return id;
     }

     public void setId(Long id) {
         this.id = id;
     }



     public String getMessage() {
         return message;
     }

     public void setMessage(String message) {
         this.message = message;
     }

     public String getDate() {
         return date;
     }

     public void setDate(String date) {
         this.date = date;
     }


 }