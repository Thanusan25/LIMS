package com.grokonez.jwtauthentication.message.request;

import javax.validation.constraints.*;
import java.util.Set;

public class AnnounceForm {


    //--------------------------------------


    @NotBlank
    @Size(min = 3, max = 50)
    private String aname;

//-----------------------------------------------------

    @NotBlank
    @Size(min = 3, max = 50)
    private String message;

    @NotBlank
    @Size(min=3, max = 100)
    private String date;

//------------------------------------------------------------------


    public String getAname() {
        return aname;
    }

    public void setAname(String aname) {
        this.aname = aname;
    }




    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

}