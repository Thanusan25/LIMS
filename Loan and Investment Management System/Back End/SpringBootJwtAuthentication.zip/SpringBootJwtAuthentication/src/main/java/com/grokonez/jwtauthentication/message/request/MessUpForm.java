package com.grokonez.jwtauthentication.message.request;

import javax.validation.constraints.*;
import java.util.Set;

public class MessUpForm {


    //--------------------------------------

    @NotBlank
    @Size(min = 3, max = 50)
    private String fromuname;


    @NotBlank
    @Size(min = 3, max = 50)
    private String touname;


    @NotBlank
    @Size(min = 3, max = 50)
    private String uname;

//-----------------------------------------------------

    @NotBlank
    @Size(min = 3, max = 50)
    private String name;


    @NotBlank
    @Size(min=3, max = 100)
    private String date;




//------------------------------------------------------------------

    public String getFromuname() {
        return fromuname;
    }

    public void setFromuuname(String fromuname) {
        this.fromuname = fromuname;
    }


    public String getTouname() {
        return touname;
    }

    public void setTouname(String touname) {
        this.touname = touname;
    }


    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }


    //-----------------------------------------------------------------




    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}