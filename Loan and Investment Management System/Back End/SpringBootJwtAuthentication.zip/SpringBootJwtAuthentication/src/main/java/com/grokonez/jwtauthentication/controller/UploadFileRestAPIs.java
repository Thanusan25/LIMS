package com.grokonez.jwtauthentication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import com.grokonez.jwtauthentication.model.FileModel;
import com.grokonez.jwtauthentication.repository.FileRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController

@RequestMapping("/api/auth")
public class UploadFileRestAPIs {
    @Autowired
    FileRepository fileRepository;

    //MultipartFile Upload

    @PostMapping("/api/file/upload")
    public String uploadMultipartFile(@RequestParam("file") MultipartFile file) {
        try {
            // save file to PostgreSQL
            FileModel filemode = new FileModel(file.getOriginalFilename(), file.getContentType(), file.getBytes());
            fileRepository.save(filemode);
            return "File uploaded successfully! -> filename = " + file.getOriginalFilename();
        } catch (	Exception e) {
            return "FAIL! Maybe You had uploaded the file before or the file's size > 500KB";
        }
    }
}
