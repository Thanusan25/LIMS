package com.grokonez.jwtauthentication.repository;

import com.grokonez.jwtauthentication.model.UseraReq;
import com.grokonez.jwtauthentication.model.UserdReq;
import com.grokonez.jwtauthentication.model.Usermess;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserdreqRepository extends JpaRepository<UserdReq, Long> {


    List<UserdReq> findByUname(String uname);



}
