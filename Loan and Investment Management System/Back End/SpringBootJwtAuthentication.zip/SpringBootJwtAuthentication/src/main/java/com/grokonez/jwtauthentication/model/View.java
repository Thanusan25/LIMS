package com.grokonez.jwtauthentication.model;

public class View {
    public interface FileInfo {}
}
