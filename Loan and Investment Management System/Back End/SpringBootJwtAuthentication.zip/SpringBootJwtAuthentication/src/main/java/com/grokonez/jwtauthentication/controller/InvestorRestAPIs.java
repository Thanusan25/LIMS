package com.grokonez.jwtauthentication.controller;

import com.grokonez.jwtauthentication.message.request.*;
import com.grokonez.jwtauthentication.message.response.ResponseMessage;
import com.grokonez.jwtauthentication.model.*;
import com.grokonez.jwtauthentication.repository.*;
import com.grokonez.jwtauthentication.security.jwt.JwtProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
//@PreAuthorize("hasAnyAuthority('ROLE_ADMIN')")
@RequestMapping("/api/auth")
public class InvestorRestAPIs {


    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    UserRepository userRepository;

    @Autowired
    UseraRepository useraRepository;

    @Autowired
    UserbRepository userbRepository;

    @Autowired
    UsercRepository usercRepository;

    @Autowired
    UserdRepository userdRepository;


    @Autowired
    UsermessRepository usermessRepository;


    @Autowired
    LawyerRepository lawyerRepository;

    @Autowired
    UserareqRepository userareqRepository;
    @Autowired
    UserbreqRepository userbreqRepository;
    @Autowired
    UsercreqRepository usercreqRepository;
    @Autowired
    UserdreqRepository userdreqRepository;



    @Autowired
    AnnounceRepository announceRepository;



    @Autowired
    UserareqstatusRepository userareqstatusRepository;
    @Autowired
    UserbreqstatusRepository userbreqstatusRepository;
    @Autowired
    UsercreqstatusRepository usercreqstatusRepository;
    @Autowired
    UserdreqstatusRepository userdreqstatusRepository;


    @Autowired
    RoleRepository roleRepository;
    @Autowired
    Role1Repository role1Repository;

    @Autowired
    PasswordEncoder encoder;

    @Autowired
    JwtProvider jwtProvider;


    // userc detatils

    @PostMapping("/igsignup")
    public ResponseEntity<?> registerUserc(@Valid @RequestBody IgsignUpForm signUpRequest) {

        // Creating user's account
        Userc userc = new Userc(signUpRequest.getUid(),signUpRequest.getUname(),signUpRequest.getName(), signUpRequest.getAreas(), signUpRequest.getMinrate(),signUpRequest.getAbout());


        usercRepository.save(userc);

        return new ResponseEntity<>(new ResponseMessage("Userc registered successfully!"), HttpStatus.OK);
    }


    @GetMapping("/userc")
    public List<Userc> getAllUsercs() {

        System.out.println("Get all Usercs...");

        List<Userc> usercs = new ArrayList<>();
        usercRepository.findAll().forEach(usercs::add);

        return usercs;

    }


    @DeleteMapping("/userc/{id}")
    public ResponseEntity<String> deleteUserc(@PathVariable("id") long id) {
        System.out.println("Delete usercs with ID = " + id + "...");

        usercRepository.deleteById(id);

        return new ResponseEntity<>("Userc has been deleted!", HttpStatus.OK);
    }

    @DeleteMapping("/userc/delete")
    public ResponseEntity<String> deleteAllUsercs() {
        System.out.println("Delete All usercs...");

        usercRepository.deleteAll();

        return new ResponseEntity<>("All Usercs have been deleted!", HttpStatus.OK);
    }


    @GetMapping(value = "userc/uid/{uid}")
    public Optional<Userc> findByU_id(@PathVariable Integer uid) {

        Optional<Userc> usercs = usercRepository.findByUid(uid);
        return usercs;
    }

    @GetMapping(value = "userc/uname/{uname}")
    public Optional<Userc> findByUnamec(@PathVariable String uname) {

        Optional<Userc> usercs = usercRepository.findByUname(uname);
        return usercs;
    }
//----------------------------------------------------------------------------------------------

}

