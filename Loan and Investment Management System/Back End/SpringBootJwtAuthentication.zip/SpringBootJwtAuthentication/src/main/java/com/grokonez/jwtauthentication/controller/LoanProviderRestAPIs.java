package com.grokonez.jwtauthentication.controller;

import com.grokonez.jwtauthentication.message.request.*;
import com.grokonez.jwtauthentication.message.response.ResponseMessage;
import com.grokonez.jwtauthentication.model.*;
import com.grokonez.jwtauthentication.repository.*;
import com.grokonez.jwtauthentication.security.jwt.JwtProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
//@PreAuthorize("hasAnyAuthority('ROLE_ADMIN')")
@RequestMapping("/api/auth")
public class LoanProviderRestAPIs {


    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    UserRepository userRepository;

    @Autowired
    UseraRepository useraRepository;

    @Autowired
    UserbRepository userbRepository;

    @Autowired
    UsercRepository usercRepository;

    @Autowired
    UserdRepository userdRepository;


    @Autowired
    UsermessRepository usermessRepository;


    @Autowired
    LawyerRepository lawyerRepository;

    @Autowired
    UserareqRepository userareqRepository;
    @Autowired
    UserbreqRepository userbreqRepository;
    @Autowired
    UsercreqRepository usercreqRepository;
    @Autowired
    UserdreqRepository userdreqRepository;



    @Autowired
    AnnounceRepository announceRepository;



    @Autowired
    UserareqstatusRepository userareqstatusRepository;
    @Autowired
    UserbreqstatusRepository userbreqstatusRepository;
    @Autowired
    UsercreqstatusRepository usercreqstatusRepository;
    @Autowired
    UserdreqstatusRepository userdreqstatusRepository;


    @Autowired
    RoleRepository roleRepository;
    @Autowired
    Role1Repository role1Repository;

    @Autowired
    PasswordEncoder encoder;

    @Autowired
    JwtProvider jwtProvider;


    //---------------------------------------------------------------------------------------------
    // usera detatils

    @PostMapping("/psignup")
    public ResponseEntity<?> registerUsera(@Valid @RequestBody PsignUpForm signUpRequest) {

        // Creating user's account
        Usera usera = new Usera(signUpRequest.getUid(),signUpRequest.getUname(),signUpRequest.getName(), signUpRequest.getMinage(), signUpRequest.getMinsalary(),signUpRequest.getAbout());


        useraRepository.save(usera);

        return new ResponseEntity<>(new ResponseMessage("Usera registered successfully!"), HttpStatus.OK);
    }


    @GetMapping("/usera")
    public List<Usera> getAllUseras() {

        System.out.println("Get all Useras...");

        List<Usera> useras = new ArrayList<>();
        useraRepository.findAll().forEach(useras::add);

        return useras;

    }


    @DeleteMapping("/usera/{id}")
    public ResponseEntity<String> deleteUsera(@PathVariable("id") long id) {
        System.out.println("Delete users with ID = " + id + "...");

        useraRepository.deleteById(id);

        return new ResponseEntity<>("Usera has been deleted!", HttpStatus.OK);
    }

    @DeleteMapping("/usera/delete")
    public ResponseEntity<String> deleteAllUseras() {
        System.out.println("Delete All useras...");

        useraRepository.deleteAll();

        return new ResponseEntity<>("All Useras have been deleted!", HttpStatus.OK);
    }


    @GetMapping(value = "usera/uid/{uid}")
    public Optional<Usera> findByU_ida(@PathVariable Integer uid) {

        Optional<Usera> useras = useraRepository.findByUid(uid);
        return useras;
    }


    @GetMapping(value = "usera/uname/{uname}")
    public Optional<Usera> findByUnamea(@PathVariable String uname) {

        Optional<Usera> useras = useraRepository.findByUname(uname);
        return useras;
    }

}

