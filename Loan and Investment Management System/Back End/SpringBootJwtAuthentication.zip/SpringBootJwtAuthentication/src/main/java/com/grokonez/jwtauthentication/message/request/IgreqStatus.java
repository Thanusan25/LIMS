package com.grokonez.jwtauthentication.message.request;


import javax.validation.constraints.*;
import java.util.Set;

public class IgreqStatus {


    //--------------------------------------


    @NotBlank
    @Size(min = 3, max = 50)
    private String runame;

    @NotBlank
    @Size(min = 3, max = 50)
    private String suname;



    @NotNull
    @Min(value =1)
    private Integer reqid;


    @NotBlank
    @Size(min = 3, max = 50)
    private String receiverstatus;


    @NotBlank
    @Size(min = 3, max = 50)
    private String senderstatus;

    @NotBlank
    @Size(min = 3, max = 50)
    private String lawyer;


    @NotBlank
    @Size(min=3, max = 50)
    private String comments;




//------------------------------------------------------------------


    public String getRuname() {
        return runame;
    }

    public void setRuname(String runame) {
        this.runame = runame;
    }

    public String getSuname() {
        return suname;
    }

    public void setSuname(String suname) {
        this.suname = suname;
    }

    public Integer getReqid() {
        return reqid;
    }

    public void setReqid(Integer reqid) {
        this.reqid = reqid;
    }

    public String getReceiverstatus() {
        return receiverstatus;
    }

    public void setReceiverstatus(String receiverstatus) {
        this.receiverstatus = receiverstatus;
    }

    public String getSenderstatus() {
        return senderstatus;
    }

    public void setSenderstatus(String senderstatus) {
        this.senderstatus = senderstatus;
    }

    public String getLawyer() {
        return lawyer;
    }

    public void setLawyer(String lawyer) {
        this.lawyer = lawyer;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

}