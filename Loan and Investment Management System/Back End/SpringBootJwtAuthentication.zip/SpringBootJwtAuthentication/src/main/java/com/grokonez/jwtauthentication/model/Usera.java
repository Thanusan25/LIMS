package com.grokonez.jwtauthentication.model;

import org.hibernate.annotations.NaturalId;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "usersa", uniqueConstraints = {
        @UniqueConstraint(columnNames = {
                "uid"
        }),
        @UniqueConstraint(columnNames = {
                "uname"
        })
})
public class Usera {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Min(value =1)
    private Integer uid;


    @NotBlank
    @Size(min = 3, max = 50)
    private String uname;


    @NotBlank
    @Size(min=3, max = 50)
    private String name;

    @NotBlank
    @Size(min=0, max = 50)
    private String minage;


    @NotBlank
    @Size(min=0, max = 100)
    private String minsalary;

    @NotBlank
    @Size(min=3, max = 100)
    private String about;


    public Usera() {}

    public Usera(Integer uid,String uname,String name, String minage, String minsalary, String about) {
        this.uid = uid;
        this.uname = uname;
        this.name = name;
        this.minage = minage;
        this.minsalary = minsalary;
        this.about= about;

    }



    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }


    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMinage() {
        return minage;
    }

    public void setMinage(String minage) {
        this.minage = minage;
    }

    public String getMinsalary() {
        return minsalary;
    }

    public void setMinsalary(String minsalary) {
        this.minsalary = minsalary;
    }

    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }
}