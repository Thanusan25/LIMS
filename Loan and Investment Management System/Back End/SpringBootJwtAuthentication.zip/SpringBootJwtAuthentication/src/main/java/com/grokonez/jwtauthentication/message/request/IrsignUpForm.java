package com.grokonez.jwtauthentication.message.request;

import javax.validation.constraints.*;
import java.util.Set;

public class IrsignUpForm {

//user d
//--------------------------------------
@Min(value =1)
private int uid;


    @NotBlank
    @Size(min = 3, max = 50)
    private String uname;

//-----------------------------------------------------

    @NotBlank
    @Size(min = 3, max = 50)
    private String name;

    @NotBlank
    @Size(min=3, max = 50)
    private String yearsofoccupation;

    @NotBlank
    @Size(min=3, max = 50)
    private String salary;

//g mean gurrantee

    @NotBlank
    @Size(min=6, max = 100)
    private String gname;

    @NotBlank
    @Size(min=6, max = 100)
    private String gnic;

    @NotBlank
    @Size(min=6, max = 100)
    private String gphonenumber;

    @NotBlank
    @Size(min=6, max = 100)
    private String gjob;


    @NotBlank
    @Size(min=6, max = 100)
    private String grelationship;

//------------------------------------------------------------------


    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }


    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    //-----------------------------------------------------------------




    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getYearsofoccupation() {
        return yearsofoccupation;
    }

    public void setYearsofoccupation(String yearsofoccupation) {
        this.yearsofoccupation = yearsofoccupation;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public String getGname() {
        return gname;
    }

    public void setGname(String gname) {
        this.gname = gname;
    }

    public String getGnic() {
        return gnic;
    }

    public void setGnic(String gnic) {
        this.gnic = gnic;
    }

    public String getGphonenumber() {
        return gphonenumber;
    }

    public void setGphonenumber(String gphonenumber) {
        this.gphonenumber = gphonenumber;
    }

    public String getGjob() {
        return gjob;
    }

    public void setGjob(String gjob) {
        this.gjob = gjob;
    }

    public String getGrelationship() {
        return grelationship;
    }

    public void setGrelationship(String grelationship) {
        this.grelationship = grelationship;
    }
}


