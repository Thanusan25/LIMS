package com.grokonez.jwtauthentication.controller;

import com.grokonez.jwtauthentication.message.request.*;
import com.grokonez.jwtauthentication.message.response.ResponseMessage;
import com.grokonez.jwtauthentication.model.*;
import com.grokonez.jwtauthentication.repository.*;
import com.grokonez.jwtauthentication.security.jwt.JwtProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
//@PreAuthorize("hasAnyAuthority('ROLE_ADMIN')")
@RequestMapping("/api/auth")
public class LoanReceiverRestAPIs {


    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    UserRepository userRepository;

    @Autowired
    UseraRepository useraRepository;

    @Autowired
    UserbRepository userbRepository;

    @Autowired
    UsercRepository usercRepository;

    @Autowired
    UserdRepository userdRepository;


    @Autowired
    UsermessRepository usermessRepository;


    @Autowired
    LawyerRepository lawyerRepository;

    @Autowired
    UserareqRepository userareqRepository;
    @Autowired
    UserbreqRepository userbreqRepository;
    @Autowired
    UsercreqRepository usercreqRepository;
    @Autowired
    UserdreqRepository userdreqRepository;



    @Autowired
    AnnounceRepository announceRepository;



    @Autowired
    UserareqstatusRepository userareqstatusRepository;
    @Autowired
    UserbreqstatusRepository userbreqstatusRepository;
    @Autowired
    UsercreqstatusRepository usercreqstatusRepository;
    @Autowired
    UserdreqstatusRepository userdreqstatusRepository;


    @Autowired
    RoleRepository roleRepository;
    @Autowired
    Role1Repository role1Repository;

    @Autowired
    PasswordEncoder encoder;

    @Autowired
    JwtProvider jwtProvider;



    // userb detatils

    @PostMapping("/ssignup")
    public ResponseEntity<?> registerUserb(@Valid @RequestBody SsignUpForm signUpRequest) {

        // Creating user's account
        Userb userb = new Userb(signUpRequest.getUid(),signUpRequest.getUname(),signUpRequest.getName(), signUpRequest.getYearsofoccupation(), signUpRequest.getSalary(), signUpRequest.getName(), signUpRequest.getGnic(), signUpRequest.getGphonenumber(), signUpRequest.getGjob(), signUpRequest.getGrelationship());


        userbRepository.save(userb);

        return new ResponseEntity<>(new ResponseMessage("Userb registered successfully!"), HttpStatus.OK);
    }


    @GetMapping("/userb")
    public List<Userb> getAllUserbs() {

        System.out.println("Get all Userbs...");

        List<Userb> userbs = new ArrayList<>();
        userbRepository.findAll().forEach(userbs::add);

        return userbs;

    }


    @DeleteMapping("/userb/{id}")
    public ResponseEntity<String> deleteUserb(@PathVariable("id") long id) {
        System.out.println("Delete userbs with ID = " + id + "...");

        userbRepository.deleteById(id);

        return new ResponseEntity<>("Userb has been deleted!", HttpStatus.OK);
    }

    @DeleteMapping("/userb/delete")
    public ResponseEntity<String> deleteAllUserbs() {
        System.out.println("Delete All userbs...");

        userbRepository.deleteAll();

        return new ResponseEntity<>("All Userbs have been deleted!", HttpStatus.OK);
    }


    @GetMapping(value = "userb/uid/{uid}")
    public Optional<Userb> findByU_idb(@PathVariable Integer uid) {

        Optional<Userb> userbs = userbRepository.findByUid(uid);
        return userbs;
    }
    @GetMapping(value = "userb/uname/{uname}")
    public Optional<Userb> findByUnameb(@PathVariable String uname) {

        Optional<Userb> userbs = userbRepository.findByUname(uname);
        return userbs;
    }
//-----------------------------------------------------------------------


}
