package com.grokonez.jwtauthentication.message.request;

import javax.validation.constraints.*;
import java.util.Set;

public class IgsignUpForm {
//user c

    //--------------------------------------
    @Min(value =1)
    private int uid;


    @NotBlank
    @Size(min = 3, max = 50)
    private String uname;

//-----------------------------------------------------

    @NotBlank
    @Size(min = 3, max = 50)
    private String name;

    @NotBlank
    @Size(min=3, max = 50)
    private String areas;

    @NotBlank
    @Size(min=6, max = 100)
    private String minrate;

    @NotBlank
    @Size(min=6, max = 100)
    private String about;

//------------------------------------------------------------------

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }


    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }


    //-----------------------------------------------------------------




    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getAreas() {
        return areas;
    }

    public void setAreas(String areas) {
        this.areas = areas;
    }

    public String getMinrate() {
        return minrate;
    }

    public void setMinrate(String minrate) {
        this.minrate = minrate;
    }

    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }


}