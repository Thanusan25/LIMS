package com.grokonez.jwtauthentication.message.request;

import javax.validation.constraints.*;
import java.util.Set;

public class IgreqForm {


    //--------------------------------------

    @NotBlank
    @Size(min = 3, max = 50)
    private String uname;

    @NotNull
    @Min(value =1)
    private Integer amount;


    @NotNull
    @Min(value =1)
    private Integer duration;

    @NotNull
    @Min(value =1)
    private Integer rate;



    @NotBlank
    @Size(min=3, max = 50)
    private String negotiation;


    @NotBlank
    @Size(min=3, max = 100)
    private String date;



//------------------------------------------------------------------


    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }


    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }


    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }


    public Integer getRate() {
        return rate;
    }

    public void setRate(Integer rate) {
        this.rate = rate;
    }


    public String getNegotiation() {
        return negotiation;
    }

    public void setNegotiation(String negotiation) {
        this.negotiation = negotiation;
    }



    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}