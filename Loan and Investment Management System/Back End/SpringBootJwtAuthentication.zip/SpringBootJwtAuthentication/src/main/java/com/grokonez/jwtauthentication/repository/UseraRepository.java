package com.grokonez.jwtauthentication.repository;

import com.grokonez.jwtauthentication.model.Usera;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UseraRepository extends JpaRepository<Usera, Long> {
    Optional<Usera> findByUid(Integer uid);
    Optional<Usera> findByUname(String uname);


}