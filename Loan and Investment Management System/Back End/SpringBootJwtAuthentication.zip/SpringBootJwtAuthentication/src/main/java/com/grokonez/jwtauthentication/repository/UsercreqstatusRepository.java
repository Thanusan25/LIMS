
package com.grokonez.jwtauthentication.repository;

import com.grokonez.jwtauthentication.model.UsercReqStatus;
import com.grokonez.jwtauthentication.model.Usermess;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UsercreqstatusRepository extends JpaRepository<UsercReqStatus, Long> {


    List<UsercReqStatus> findByRuname(String runame);
    List<UsercReqStatus> findByRunameAndReceiverstatus(String runame,String receiverstatus);
    Optional<UsercReqStatus> findByRunameAndReceiverstatusAndReqid(String runame,String receiverstatus,Integer reqid);

    Optional<UsercReqStatus> findById(Long id);


}
