package com.grokonez.jwtauthentication.model;

import org.hibernate.annotations.NaturalId;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "usersd", uniqueConstraints = {
        @UniqueConstraint(columnNames = {
                "uid"
        }),
        @UniqueConstraint(columnNames = {
                "uname"
        })
})
public class Userd {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Min(value =1)
    private Integer uid;


    @NotBlank
    @Size(min = 3, max = 50)
    private String uname;

    @NotBlank
    @Size(min = 3, max = 50)
    private String name;

    @NotBlank
    @Size(min=3, max = 50)
    private String yearsofoccupation;

    @NotBlank
    @Size(min=3, max = 50)
    private String salary;

//g mean gurrantee

    @NotBlank
    @Size(min=6, max = 100)
    private String gname;

    @NotBlank
    @Size(min=6, max = 100)
    private String gnic;

    @NotBlank
    @Size(min=6, max = 100)
    private String gphonenumber;

    @NotBlank
    @Size(min=6, max = 100)
    private String gjob;


    @NotBlank
    @Size(min=6, max = 100)
    private String grelationship;


    public Userd() {}

    public Userd(Integer uid,String uname,String name, String yearsofoccupation, String salary, String gname,String gnic,String gphonenumber, String gjob, String grelationship) {
        this.uid = uid;
        this.uname = uname;
        this.name = name;
        this.yearsofoccupation = yearsofoccupation;
        this.salary = salary;
        this.gname = gname;
        this.gnic = gnic;
        this.gphonenumber = gphonenumber;
        this.gjob = gjob;
        this.grelationship = grelationship;

    }



    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }


    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }



    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getYearsofoccupation() {
        return yearsofoccupation;
    }

    public void setYearsofoccupation(String yearsofoccupation) {
        this.yearsofoccupation = yearsofoccupation;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public String getGname() {
        return gname;
    }

    public void setGname(String gname) {
        this.gname = gname;
    }

    public String getGnic() {
        return gnic;
    }

    public void setGnic(String gnic) {
        this.gnic = gnic;
    }

    public String getGphonenumber() {
        return gphonenumber;
    }

    public void setGphonenumber(String gphonenumber) {
        this.gphonenumber = gphonenumber;
    }

    public String getGjob() {
        return gjob;
    }

    public void setGjob(String gjob) {
        this.gjob = gjob;
    }

    public String getGrelationship() {
        return grelationship;
    }

    public void setGrelationship(String grelationship) {
        this.grelationship = grelationship;
    }
}